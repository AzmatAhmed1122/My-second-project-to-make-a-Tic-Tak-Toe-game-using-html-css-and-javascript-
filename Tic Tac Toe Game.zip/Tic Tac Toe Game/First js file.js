let buttonsall=document.querySelectorAll(".box");
let resetbuttonis=document.querySelector(".resseting457878");
let newgame=document.querySelector(".topratedfirst45");
let winnnner1=document.querySelector(".Thecongrajulationtexting458");

let startx=true;
let winpattren=[
[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
];
 let windiv1=document.querySelector(".firstmaindivshowwinner");
 windiv1.style.display="none";
 

resetbuttonis.addEventListener("click",()=>{
	buttonsall.forEach(button=>{
		button.innerText="";
		button.disabled=false;
	})
});

//newgame
newgame.addEventListener("click",()=>{
buttonsall.forEach(button=>{
		button.innerText="";
		button.disabled=false;
		 windiv1.style.display="none";
	})
});



buttonsall.forEach(function(buttonsall){


	buttonsall.addEventListener("click",()=>{
console.log("Submited");
/*newgame.classList.add("hidden");
winnnner.classList.add("hidden");*/

if(startx){
	buttonsall.innerText="X";
	startx=false;
}
else{
		buttonsall.innerText="O";
			startx=true;
}
buttonsall.disabled=true;
winnerfunc();

	});
});


//make winner function

const winnerfunc=()=>{
	for(let pattren of winpattren){

		let pat1=buttonsall[pattren[0]].innerText;
		let patt2=buttonsall[pattren[1]].innerText;
		let pata3=buttonsall[pattren[2]].innerText;
		if( pat1!="" && patt2!="" && pata3!="" ){
			if(pat1==patt2&&patt2==pata3){
				console.log("Congrajulations");
				tostopbuttons();
				 windiv1.style.display="block";
showwinnner(pat1);

			}
		}
	}
}



//Disable button function

const tostopbuttons=()=>{
	for(let btons of buttonsall ){
		btons.disabled=true;
	}
}

//show winner function

const showwinnner=(winner)=>{
let winelement=document.querySelector(".Thecongrajulationtexting458");
if( winelement){
	let winmess=`winner is ${winner}`;
	winelement.textContent=winmess;
	winelement.style.display="block";
}

};
